const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const  Produto = sequelize.define('Produtos', {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false
    },
    catogory: {
        type: DataTypes.STRING,
        allowNull: false
    }
})

module.exports = Produto;