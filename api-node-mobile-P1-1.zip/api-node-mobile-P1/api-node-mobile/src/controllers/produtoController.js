const express = require('express');
const productService = require('../services/produtoService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

router.get('/',  async (req, res) =>{
    try{
        const product = await productService.getProduct();
        res.json(product);
    }
    catch(error){
        res.status(400).json({error: error.message});
    }
})

router.post('/', authenticateToken,async(req,res) =>{
    const { name, price, description, category } = req.body;
    const product = await productService.register(name, price, description, category);
    res.status(201).json(product);
})

module.exports = router;